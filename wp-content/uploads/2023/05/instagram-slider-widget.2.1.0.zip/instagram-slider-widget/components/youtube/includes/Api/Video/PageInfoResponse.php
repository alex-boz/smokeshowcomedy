<?php


namespace YoutubeFeed\Api\Video;

/**
 * Class PageInfoResponse
 *
 * @property int $totalResults
 * @property int $resultsPerPage
 *
 * @package YoutubeFeed\includes\Api
 */
class PageInfoResponse
{

}