<?php


namespace YoutubeFeed\Api\Channel;

/**
 * Class YoutubeChannelId
 *
 * @property string $kind
 * @property string $channelId
 *
 * @package YoutubeFeed\Api\Channel
 */
class YoutubeChannelId
{

}