<?php


namespace YoutubeFeed\Api\Common;


/**
 * Class YoutubeThumbnails
 *
 * @property YoutubeThumbnail $default
 * @property YoutubeThumbnail $medium
 * @property YoutubeThumbnail $high
 *
 * @package YoutubeFeed\includes\Api
 */
class YoutubeThumbnails
{

}